import numpy as np

ar = np.random.randint(1, 50, (5))

ar2 = np.random.randint(1, 50, (5))

print(np.dot(ar, ar2))

print(np.linalg.norm(ar))

print(np.linalg.norm(ar2))

print(np.corrcoef(ar, ar2))