import numpy as np

lis = np.linspace(0,1, num=5, endpoint=True)
print(lis)

print(np.sum(lis, axis=0))

print(np.mean(lis, axis=0))

print(np.std(lis, axis=0))

print(np.prod(lis, axis=0))