import numpy

ar1 = numpy.arange(10, 50, 5)
print('\n', ar1)

ar2 = numpy.reshape(ar1, (2,4))
print('\n', ar2)