import numpy as np

ar = np.random.randint(-50, 50, (10))

print(np.abs(ar))

print(np.clip(ar, 10, 40))

ord=np.sort(ar)

neg,post=np.split(ord, 2)

print(np.sqrt(post))

print(np.log(post))