import numpy as np

ar = np.random.randint(1, 9, (3,3))
print(ar)

trans=np.transpose(ar)
print(trans)

flat=trans.flatten()
print(flat)

rdon=np.round(flat)
print(rdon)

suma=np.sum(rdon)
print(suma)

media=np.mean(rdon)
print(media)

desv=np.std(rdon)
print(desv)