import numpy as np

ar = np.array([2, 4, 6, 8, 10])

print("Minimo: ", np.min(ar, axis =0), "\nMaximo: ", np.max(ar, axis = 0), "\nMedia: ", np.mean(ar, axis = 0), "\nVariansa", np.var(ar, axis = 0), "\nLogaritmo natural: ", np.log(ar))