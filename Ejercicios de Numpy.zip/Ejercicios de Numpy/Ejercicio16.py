import numpy as np

ar = np.random.randint(1, 100, (15))

may=np.where(ar>50)

print(may)

ord=np.argsort(ar)

print(ord)

idx=np.searchsorted(ar, 42)

print(idx)