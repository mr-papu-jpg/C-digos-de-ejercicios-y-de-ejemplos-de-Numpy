import numpy

z1=numpy.zeros((3,4), dtype=int)
print('\n',z1)

z1=numpy.ones((3,4), dtype=int)
print('\n',z1)

z1=numpy.ones((3,4), dtype=float)
print('\n',z1)